package com.example.appbahan;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;

public class FragmentA extends Fragment {
    private CheckBox checkKerupuk, checkTelur, checkSosis, checkBakso;
    private Button buttonLihatPilihan;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_a, container, false);

        // Inisialisasi komponen
        checkKerupuk = view.findViewById(R.id.checkKerupuk);
        checkTelur = view.findViewById(R.id.checkTelur);
        checkSosis = view.findViewById(R.id.checkSosis);
        checkBakso = view.findViewById(R.id.checkBakso);
        buttonLihatPilihan = view.findViewById(R.id.buttonLihatPilihan);

        buttonLihatPilihan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Ambil pilihan dari CheckBox
                StringBuilder bahanSeblak = new StringBuilder();
                if (checkKerupuk.isChecked()) bahanSeblak.append("Kerupuk, ");
                if (checkTelur.isChecked()) bahanSeblak.append("Telur, ");
                if (checkSosis.isChecked()) bahanSeblak.append("Sosis, ");
                if (checkBakso.isChecked()) bahanSeblak.append("Bakso, ");

                // Hapus koma terakhir
                if (bahanSeblak.length() > 0) {
                    bahanSeblak.setLength(bahanSeblak.length() - 2);
                }

                // Buat bundle untuk mengirim data ke FragmentDua
                FragmentB fragmentB = new FragmentB();
                Bundle bundle = new Bundle();
                bundle.putString("bahanSeblak", bahanSeblak.toString());
                fragmentB.setArguments(bundle);

                // Ganti fragment
                FragmentTransaction transaction = getFragmentManager().beginTransaction();
                transaction.replace(R.id.fragment_container, fragmentB);
                transaction.addToBackStack(null);
                transaction.commit();
            }
        });

        return view;
    }
}